# TSP-Genetic-Algorithm

### Instructions to run files 

1. Open directory in command prompt
2. Install dependencies using the command: ***pip install -r requirements.txt***
3. Run problem 1 using the command: ***python TSP_problem1.py***
4. Run problem 2 using the command: ***python TSP_problem2.py***
5. And Check the dependenices related to that
